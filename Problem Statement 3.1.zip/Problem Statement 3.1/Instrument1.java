package Project3;

public abstract class Instrument1
{
public abstract void Play();
}
