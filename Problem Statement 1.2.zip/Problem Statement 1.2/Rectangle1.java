package Project1;

class Rectangle1{
	public int length;
	public int breadth;
	public int area;


	//default constructor
	public Rectangle1() {
	}


	//Constructor
	public Rectangle1(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}
	
	//find area of rectangle
	public void printArea() {
		area = length * breadth;
		System.out.println("Area of Rectangle : " + area);
	}

// display all data of rectangle
	public void printData() {
		System.out.println("Length of Rectangle is : " + length);
		System.out.println("Breadth of Rectangle is : " + breadth);
	
	}
	
}
 class Rectangle1_problem {
	public static void main(String[] args) {
		Rectangle1 rec2 = new Rectangle1(6, 3);
		
		rec2.printData();
		rec2.printArea();
		
		


	}

	
}


