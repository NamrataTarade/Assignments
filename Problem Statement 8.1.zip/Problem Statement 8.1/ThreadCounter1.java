package Project8;

import java.lang.Runnable;

class Storage1

{

	private int x;

	public Storage1(int X) {
		x = X;
	}

	public int GetX() {
		return (x);
	}

	public Storage1(Storage1 s) {
		this.x = s.GetX();
	}

}

class Printer1 implements Runnable

{

	private Storage1 storage;

	Printer1(Storage1 s) {
		storage = new Storage1(s);
	}

	public void run()

	{

		System.out.println(storage.GetX());

	}

}

class Counter1 implements Runnable

{

	private int N;

	public Counter1(int n) {
		N = n;
	}

	public int GetN() {
		return (N);
	}

	public void run()

	{

		for (int iLoop = 1; iLoop <= N; iLoop++)

		{

			Storage1 storage = new Storage1(iLoop);

			Printer1 printer = new Printer1(storage);

			Thread.yield();

			printer.run();

		}

	}

}

class ThreadCounter1

{

	public static void main(String args[])

	{

		Counter1 counter = new Counter1(25);

		counter.run();

	}

}
