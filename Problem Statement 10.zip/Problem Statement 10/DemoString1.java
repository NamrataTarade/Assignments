package program10;

import java.util.Scanner;

class DemoString1
{
	
	public static boolean isInterleaving(String first, String second, String third)
	{
		
		if (first.length() == 0 && second.length() == 0 && third.length() == 0) {
			return true;
		}

		if (third.length() == 0) {
			return false;
		}


		boolean x = (first.length() != 0 && third.charAt(0) == first.charAt(0)) &&
				isInterleaving(first.substring(1), second, third.substring(1));


		boolean y = (second.length() != 0 && third.charAt(0) == second.charAt(0)) &&
				isInterleaving(first, second.substring(1), third.substring(1));

		return x || y;
	}

	public static void main(String[] args)
	{
		
		
		Scanner S=new Scanner(System.in);
		System.out.println("Enter The First String :");
		String first=S.nextLine();
		System.out.println("Enter The Second String :");
		String second=S.nextLine();
		System.out.println("Enter The Third String :");
		String third=S.nextLine();		
		

		if (isInterleaving(first, second, third)) {
			System.out.print("Interleaving");
		}
		else {
			System.out.print("Given string is not interleaving of first and second");
		}
	}
}